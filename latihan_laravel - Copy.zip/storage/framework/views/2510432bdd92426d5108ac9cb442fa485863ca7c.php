<form action="" method="post">
	<?php echo csrf_field(); ?>

	<table>
		<tr>
			<td>Name</td><td>:</td><td><input type="text" size="40" required name="name" value="<?php echo e($row->name); ?>" /></td>
		</tr>
		<tr>
			<td>Address</td><td>:</td><td><input type="text" size="40" required name="address" value="<?php echo e($row->address); ?>" /></td>
		</tr>
		<tr>
			<td>Phone</td><td>:</td><td><input type="text" size="40" required name="phone" value="<?php echo e($row->phone); ?>" /></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>
				<input type="submit" value="Simpan" />
			</td>
		</tr>
	</table>
</form>