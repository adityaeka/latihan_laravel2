<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Member</title>
</head>
<body>
	<p>
		<a href="<?php echo e(url('member/create')); ?>">Tambah Data</a>
	</p>
	<table width="600px" cellspacing="0" cellpadding="10" border="1">
		<thead>
			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Address</th>
				<th>Phone</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($member->id); ?></td>
				<td><?php echo e($member->name); ?></td>
				<td><?php echo e($member->address); ?></td>
				<td><?php echo e($member->phone); ?></td>
				<td>
					<a href="<?php echo e(url('member/edit/'.$member->id)); ?>">Edit</a> / 
					<a href="<?php echo e(url('member/delete/'.$member->id)); ?>">Delete</a> 
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<p>
		<?php echo $members->appends($_GET)->links(); ?>

	</p>
</body>
</html>