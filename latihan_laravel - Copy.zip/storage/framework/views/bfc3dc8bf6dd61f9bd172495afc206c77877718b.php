<form action="" method="post">
	<?php echo csrf_field(); ?>

	<table>
		<tr>
			<td>Name</td><td>:</td><td><input type="text" size="40" required name="name" /></td>
		</tr>
		<tr>
			<td>Address</td><td>:</td><td><input type="text" size="40" required name="address" /></td>
		</tr>
		<tr>
			<td>Phone</td><td>:</td><td><input type="text" size="40" required name="phone" /></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>
				<input type="submit" value="Tambah" />
			</td>
		</tr>
	</table>
</form>